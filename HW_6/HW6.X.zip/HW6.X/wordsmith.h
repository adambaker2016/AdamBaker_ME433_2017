#ifndef wordsmith_H__
#define wordsmith_H__

void write_letter(char, char, char); //writes a letter
void write_word(char, char, char*); // writes a phrase
void make_line(char, char, unsigned short);

#endif